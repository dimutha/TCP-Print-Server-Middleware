using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing.Printing;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    
    //private TcpListener _listener;
    //private TcpListener _listener = null!;
    private TcpListener? _listener;

    public Worker(ILogger<Worker> logger)
    {
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _listener = new TcpListener(IPAddress.Any, 9100);
        _listener.Start();
        _logger.LogInformation("Listening on TCP port 9100...");

        while (!stoppingToken.IsCancellationRequested)
        {
            var client = await _listener.AcceptTcpClientAsync(stoppingToken);
            _ = Task.Run(() => HandleClient(client), stoppingToken);
        }
    }

    private async Task HandleClient(TcpClient client)
    {
        try
        {
            using var stream = client.GetStream();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);

            byte[] printData = ms.ToArray();
            SendToPrinter(GetDefaultPrinterName(), printData);

            _logger.LogInformation("Print job received and sent to printer.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling print job.");
        }
        finally
        {
            client.Close();
        }
    }

    private string GetDefaultPrinterName()
    {
        PrinterSettings settings = new PrinterSettings();
        return settings.PrinterName;
    }

    #region RAW PRINTING

    [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true)]
    static extern bool OpenPrinter(string szPrinter, out IntPtr hPrinter, IntPtr pd);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool ClosePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In] DOCINFOA di);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool EndDocPrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool StartPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool EndPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", SetLastError = true)]
    static extern bool WritePrinter(IntPtr hPrinter, byte[] bytes, int count, out int written);

    [StructLayout(LayoutKind.Sequential)]
    public class DOCINFOA
    {
        [MarshalAs(UnmanagedType.LPStr)]
        public string pDocName;
        [MarshalAs(UnmanagedType.LPStr)]
        public string pOutputFile;
        [MarshalAs(UnmanagedType.LPStr)]
        public string pDataType;
    }

    public static bool SendToPrinter(string printerName, byte[] bytes)
    {
        IntPtr hPrinter;
        DOCINFOA di = new DOCINFOA
        {
            pDocName = "RAW TCP Print Job",
            pDataType = "RAW"
        };

        if (!OpenPrinter(printerName, out hPrinter, IntPtr.Zero))
            return false;

        if (!StartDocPrinter(hPrinter, 1, di))
            return false;

        if (!StartPagePrinter(hPrinter))
            return false;

        WritePrinter(hPrinter, bytes, bytes.Length, out _);

        EndPagePrinter(hPrinter);
        EndDocPrinter(hPrinter);
        ClosePrinter(hPrinter);

        return true;
    }

    #endregion
}